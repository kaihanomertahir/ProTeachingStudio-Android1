Pro Teaching Studio Ultimate v10.7 - Android project
====================================================

این پروژه، فایل اصلی HTML نسخه v10.7 را داخل یک WebView اندروید قرار می‌دهد.
حداقل نسخه اندروید: Android 7.0 (API 24)
نسخه هدف: Android 9 (API 28)

امکانات پوسته اندروید:
- اجرای تمام‌صفحه و مستقل از مرورگر
- بارگذاری HTML از داخل خود APK با مبدأ امن appassets
- درخواست مجوز میکروفون و دوربین در زمان نیاز
- انتخاب فایل از حافظه/مدیریت فایل اندروید برای ورودی HTML
- حداقل SDK برابر 24

ساخت APK:
1. Android Studio را در رایانه باز کنید.
2. پوشه ProTeachingStudio_Android را با گزینه Open باز کنید.
3. از نصب بودن Android SDK Platform 35 و JDK 17 اطمینان حاصل کنید.
4. Gradle Sync را اجرا کنید.
5. از منوی Build > Build Bundle(s) / APK(s) > Build APK(s) را انتخاب کنید.
6. فایل APK معمولاً در مسیر app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

نکات مهم:
- این محیط فاقد Android SDK، Gradle و دستگاه/شبیه‌ساز اندروید بود؛ بنابراین APK در اینجا کامپایل یا روی دستگاه واقعی آزمایش نشده است.
- عملکرد ضبط صدا و تصویر به نسخه Android System WebView/Chrome و پشتیبانی MediaRecorder دستگاه وابسته است.
- برای استفاده از ضبط صدا، هنگام نمایش پیام سیستم، مجوز Microphone را Allow کنید.
- اگر ضبط کار نکرد، Android System WebView و Chrome را در دستگاه به‌روز کنید.
- فایل HTML اصلی بدون حذف، در app/src/main/assets/www/index.html قرار گرفته است.
